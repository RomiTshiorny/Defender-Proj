﻿using System;
namespace Defender {
    public class Map
    {
        public Map()
        {
        }
    }
}
