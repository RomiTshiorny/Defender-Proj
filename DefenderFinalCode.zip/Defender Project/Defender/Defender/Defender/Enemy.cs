﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Defender
{
    class Enemy
    {
        private Texture2D mapImage;
        private Rectangle rect;
        private Rectangle screen;
        private int Vy;
        private int Vx;
        private Random random;
        public int timer;
        public Enemy(Texture2D image, Rectangle rect, Rectangle screen)
        {
            mapImage = image;
            this.screen = screen;
            this.rect = rect;
            random = new Random();
            Vy = 0;
            Vx = 0;
            timer = 0;
        }
        public Texture2D getImage()
        {
            return mapImage;
        }
        public Rectangle getRect()
        {
            return rect;
        }
        public void move(int X, int Y)
        {
            rect = new Rectangle(rect.X + X, rect.Y + Y, rect.Width, rect.Height);
        }
        public void move(int X)
        {
            rect = new Rectangle(rect.X + X, rect.Y, rect.Width, rect.Height);
        }
        public void setRect(Rectangle rect)
        {
            this.rect = rect;
        }
        public void update(int distance)
        {
            if (rect.X < screen.X - screen.Width * 2)
            {
                rect = new Rectangle(screen.X + screen.Width * 2 - distance, rect.Y, rect.Width, rect.Height);
            }
            else if (rect.X > screen.X + screen.Width * 2)
            {
                rect = new Rectangle(screen.X - screen.Width * 2 + distance, rect.Y, rect.Width, rect.Height);
            }
            if(timer == 0)
            {
                timer = random.Next(60, 90);
                Vx = random.Next(-3, 3);
                Vy = random.Next(-3, 3);
               
            }
            if (rect.Y <= screen.Y || rect.Y > screen.Y + screen.Height)
            {
                Vy *= -1;
            }
            move(Vx, Vy);
            timer--;
        }
    }
}