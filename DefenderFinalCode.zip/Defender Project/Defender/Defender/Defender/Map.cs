﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Defender
{
    class Map
    {
        private Texture2D mapImage;
        private List<Rectangle> maps;
        private Rectangle screen;
        public Map(Texture2D image, List<Rectangle> rects, Rectangle screen)
        {
            mapImage = image;
            maps = rects;
            this.screen = screen;
        }
        public Texture2D getImage()
        {
            return mapImage;
        }
        public List<Rectangle> getList()
        {
            return maps;
        }
        public void update(int distance)
        {
            for(int i = 0; i < maps.Count; i++)
            {
                if(maps[i].X < screen.X-screen.Width*2)
                {
                    maps[i] = new Rectangle(screen.X + screen.Width*2 - distance, maps[i].Y, maps[i].Width, maps[i].Height);
                }
                else if(maps[i].X > screen.X + screen.Width*2)
                {
                    maps[i] = new Rectangle(screen.X - screen.Width*2 + distance, maps[i].Y, maps[i].Width, maps[i].Height);
                }
            }

        }
        public void move(int distance)
        {
            for (int i = 0; i < maps.Count; i++)
            {
                maps[i] = new Rectangle(maps[i].X + distance, maps[i].Y, maps[i].Width, maps[i].Height);
            }
        }
    }
}
