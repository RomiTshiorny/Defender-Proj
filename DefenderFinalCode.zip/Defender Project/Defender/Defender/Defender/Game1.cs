using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Defender
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        KeyboardState kb;
        KeyboardState oldKB;

        Ship ship;
        Texture2D shipRight;
        Texture2D shipLeft;
        Texture2D shipImage;
        Texture2D bulletTex;

        int colR;
        int colB;
        int colG;
        int r;
        int g;
        int b;

        Color mainCol;

        List<Rectangle> mapList;
        int speed;

        List<Enemy> enemies;
        Texture2D enemyTex;
        List<Vector2> velocities;

        Rectangle screen;
        Texture2D mapImage;
        Map map;

        int timer;
        List<Bullet> bulletsFired;

        Random random;
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            random = new Random();
            kb = Keyboard.GetState();
            oldKB = Keyboard.GetState();
            timer = 0;
            speed = 8;
            bulletsFired = new List<Bullet>();
            screen = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);

            colR = 0;
            colG = 175;
            colB = 255;
            r = 1;
            g = 1;
            b = -1;

            enemies = new List<Enemy>();
            velocities = new List<Vector2>();

            mapList = new List<Rectangle>();
            mapList.Add(new Rectangle(screen.X, screen.Y, screen.Width, screen.Height));
            mapList.Add(new Rectangle(screen.X + screen.Width, screen.Y, screen.Width, screen.Height));
            mapList.Add(new Rectangle(screen.X + screen.Width*2, screen.Y, screen.Width, screen.Height));
            mapList.Add(new Rectangle(screen.X - screen.Width, screen.Y, screen.Width, screen.Height));
            mapList.Add(new Rectangle(screen.X - screen.Width*2, screen.Y, screen.Width, screen.Height));
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            mapImage = this.Content.Load<Texture2D>("Background");
            shipLeft = this.Content.Load<Texture2D>("ShipLeft");
            shipRight = this.Content.Load<Texture2D>("ShipRight");
            shipImage = shipLeft;
            bulletTex = this.Content.Load<Texture2D>("bulletTex");
            enemyTex = this.Content.Load<Texture2D>("AlienNoColor");
            // TODO: use this.Content to load your game content here
            map = new Map(mapImage, mapList, screen);
            ship = new Ship(shipImage, new Rectangle(GraphicsDevice.Viewport.Width / 2, GraphicsDevice.Viewport.Height / 2, 64, 32));



        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            kb = Keyboard.GetState();
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || kb.IsKeyDown(Keys.Escape))
                this.Exit();

            // TODO: Add your update logic here
            map.update(speed);
            for (int i = 0; i < enemies.Count; i++)
            {
                enemies[i].update(speed);
            }
            if (kb.IsKeyDown(Keys.Right))
            {
                map.move(-speed);
                shipImage = shipRight;
                ship.changePointsRight(true);
                ship.moveRight();
                for (int i = 0; i < enemies.Count; i++)
                {
                    enemies[i].move(-speed);
                }
                if (ship.getxV() < 5)
                {
                    if (timer % 10 == 0)
                        ship.incrementxV();
                }
            }
            if(kb.IsKeyDown(Keys.Left))
            {
                map.move(speed);
                ship.changePointsLeft(true);
                shipImage = shipLeft;
                ship.moveLeft();
                for(int i = 0; i < enemies.Count; i++)
                {
                    enemies[i].move(speed);
                }
                if (ship.getxV() < 5)
                {
                    if (timer % 10 == 0)
                        ship.incrementxV();
                }
            }
            if (kb.IsKeyDown(Keys.Down) && ship.getShipRect().Y <= 480 - 16)
            {
                ship.moveDown();
                if (ship.getyV() < 3)
                    if (timer % 10 == 0)
                        ship.incrementyV();
            }
            if (kb.IsKeyDown(Keys.Up) && ship.getShipRect().Y >= 0)
            {
                ship.moveUp();
                if (ship.getyV() < 3)
                    if (timer % 10 == 0)
                        ship.incrementyV();
            }
            if (kb.IsKeyDown(Keys.Space) && !oldKB.IsKeyDown(Keys.Space))
            {
                if (ship.getPointsLeft())
                    bulletsFired.Add(new Defender.Bullet(bulletTex, new Rectangle(ship.getShipRect().X, ship.getShipRect().Y + 15, 6, 6), true));
                else
                    bulletsFired.Add(new Defender.Bullet(bulletTex, new Rectangle(ship.getShipRect().X + 64, ship.getShipRect().Y + 15, 6, 6), false));
                ship.shoot();
            }
            for (int i = 0; i < bulletsFired.Count; i++)
            {
                if (bulletsFired[i].getGoingLeft())
                    bulletsFired[i].moveLeft();
                else
                    bulletsFired[i].moveRight();
            }
            for(int i = 0; i < bulletsFired.Count; i++)
            {
                if(!screen.Contains(bulletsFired[i].getRect()))
                {
                    bulletsFired.RemoveAt(i);
                    i--;
                }
            }
            if(enemies.Count < 10)
            {
                enemies.Add(new Enemy(enemyTex, new Rectangle(random.Next((screen.X - screen.Width * 3), (screen.X + screen.Width * 3)), random.Next((screen.Y), (screen.Y + screen.Height)), 32, 32), screen));
            }
            if (bulletsFired.Count != 0 && enemies.Count != 0)
            {
                for (int i = 0; i < bulletsFired.Count; i++)
                {
                    for (int j = 0; j < enemies.Count; j++)
                    {
                        if (bulletsFired[i].getRect().Intersects(enemies[j].getRect()))
                        {
                            enemies.RemoveAt(j);
                        }
                    }
                }
            }
            colR = colR + r;
            colG = colG + g;
            colB = colB + b;

            if (colR == 255)
            {
                r *= -1;
            }
            if (colG == 255)
            {
                g *= -1;
            }
            if (colB == 255)
            {
                b *= -1;
            }
            if (colR == 0)
            {
                r *= -1;
            }

            if (colG == 0)
            {
                g *= -1;
            }

            if (colB == 0)
            {
                b *= -1;
            }
            mainCol = new Color(colR, colG, colB);
            oldKB = kb;
            timer++;
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            for(int i = 0; i< map.getList().Count; i++)
            {
                spriteBatch.Draw(map.getImage(), map.getList()[i], Color.White);
            }
            for (int i = 0; i < bulletsFired.Count; i++)
            {
                spriteBatch.Draw(bulletsFired[i].getTex(), bulletsFired[i].getRect(), mainCol);
            }
            for (int i = 0; i < enemies.Count; i++)
            {
                spriteBatch.Draw(enemies[i].getImage(), enemies[i].getRect(), Color.Green);
            }
            spriteBatch.Draw(shipImage, ship.getShipRect(), Color.White);
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
